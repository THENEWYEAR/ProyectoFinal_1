import React from 'react';
import './Titulos.css';

const Title = () => {
    return (
        <div className="title-container">
            <h1 className="title">Componentes en ofertas</h1>
        </div>
    );
};

export default Title;
