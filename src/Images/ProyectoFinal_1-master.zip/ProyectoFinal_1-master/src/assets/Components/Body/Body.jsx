import React from "react"
import './body.css';
import Titulos from "../Titulos/Titulos.jsx";


const Body =()=>{
    return(
        <div className="body-div">
            <Titulos/>
        </div>
    )
}

export default Body